from flask import Flask, request, send_file, render_template_string
import os

app = Flask(__name__)

# Directory to save the uploaded files
UPLOAD_FOLDER = './uploads'
PROCESSED_FOLDER = './processed'
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
os.makedirs(PROCESSED_FOLDER, exist_ok=True)

# Set the folder for uploaded files
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route('/')
def upload_form():
    return render_template_string("""
        <html>
            <body>
                <h2>Upload a Text File</h2>
                <form action="/upload" method="POST" enctype="multipart/form-data">
                    <input type="file" name="file" accept=".txt" required>
                    <input type="submit" value="Upload">
                </form>
            </body>
        </html>
    """)

@app.route('/upload', methods=['POST'])
def upload_file():
    # Check if the post request has the file part
    if 'file' not in request.files:
        return 'No file part', 400
    file = request.files['file']
    
    if file.filename == '':
        return 'No selected file', 400
    
    # Save the uploaded file
    input_file_path = os.path.join(UPLOAD_FOLDER, file.filename)
    file.save(input_file_path)

    # Process the file (convert to uppercase)
    output_file_path = os.path.join(PROCESSED_FOLDER, f"processed_{file.filename}")
    
    try:
        with open(input_file_path, 'r') as f:
            text = f.read()
        
        # Convert the content to uppercase
        uppercase_text = text.upper()

        # Save the processed content
        with open(output_file_path, 'w') as f:
            f.write(uppercase_text)

        # Return the processed file for download
        return send_file(output_file_path, as_attachment=True)

    except Exception as e:
        return f"Error processing file: {e}", 500

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5003)

