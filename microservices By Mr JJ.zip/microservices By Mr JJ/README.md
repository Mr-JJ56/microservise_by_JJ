This is the simple microservices docker sample project
which is a comosed file of three images and one nginx server
using nginx server all other app can be opened and run
all are web based

in this repo all docker images are given
first build all of these images and name as you want
then update the name of images in yml file and then 
docker compose up
