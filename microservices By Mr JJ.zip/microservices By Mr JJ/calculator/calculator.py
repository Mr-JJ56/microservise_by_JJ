from flask import Flask, render_template_string, request

app = Flask(__name__)

@app.route('/')
def home():
    return render_template_string("""
        <html>
            <body>
                <h2>Simple Calculator</h2>
                <form action="/calculate" method="POST">
                    <input type="number" name="num1" required> 
                    <select name="operation" required>
                        <option value="add">+</option>
                        <option value="subtract">-</option>
                        <option value="multiply">*</option>
                        <option value="divide">/</option>
                    </select>
                    <input type="number" name="num2" required> 
                    <button type="submit">Calculate</button>
                </form>
            </body>
        </html>
    """)

@app.route('/calculate', methods=['POST'])
def calculate():
    try:
        # Get the values from the form
        num1 = float(request.form['num1'])
        num2 = float(request.form['num2'])
        operation = request.form['operation']

        # Perform the calculation
        if operation == 'add':
            result = num1 + num2
        elif operation == 'subtract':
            result = num1 - num2
        elif operation == 'multiply':
            result = num1 * num2
        elif operation == 'divide':
            if num2 == 0:
                return "Error: Cannot divide by zero.", 400
            result = num1 / num2
        else:
            return "Invalid operation", 400

        return f"<h2>Result: {result}</h2> <br> <a href='/'>Go back</a>"

    except ValueError:
        return "Error: Invalid input. Please enter valid numbers.", 400

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5001)

